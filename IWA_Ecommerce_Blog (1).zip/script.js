
function searchItems() {
    const query = document.getElementById('search').value.toLowerCase();
    const products = document.querySelectorAll('.product');
    products.forEach(p => {
        p.style.display = p.innerText.toLowerCase().includes(query) ? 'block' : 'none';
    });
    localStorage.setItem('lastSearch', query);
}

function viewItem(item) {
    document.getElementById('modalContent').innerHTML = `<h2>${item}</h2><p>Details about ${item}...</p>`;
    document.getElementById('modal').style.display = 'block';

    let viewed = JSON.parse(localStorage.getItem('viewed')) || [];
    viewed.push(item);
    localStorage.setItem('viewed', JSON.stringify(viewed));
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function loadRecommendations() {
    const viewed = JSON.parse(localStorage.getItem('viewed')) || [];
    const lastSearch = localStorage.getItem('lastSearch');
    if (viewed.length || lastSearch) {
        let related = document.getElementById('related');
        related.innerHTML = `<h4>Recommended for you</h4>`;
        viewed.slice(-3).forEach(item => {
            related.innerHTML += `<p>Similar to: ${item}</p>`;
        });
    }
}
